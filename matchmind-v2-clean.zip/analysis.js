function generateQuickAnalysis(match){
  const status=match.fixture.status.short; const played=status==='FT';
  const home=match.teams.home.name, away=match.teams.away.name;
  const base=played?62:58; const iq=Math.min(86,base+((home.length+away.length)%17));
  return {iq,btts:Math.max(42,Math.min(72,iq-8)),over25:Math.max(38,Math.min(76,iq-12)),confidence:iq>75?'Ridicată':iq>62?'Medie':'Prudentă',
  pro:[`${home} are avantajul terenului nominal.`,`Meciul are date suficiente pentru o analiză inițială.`,`Contextul competiției poate crește intensitatea.`],
  contra:[`Fără statistici avansate gratuite, analiza rămâne estimativă.`,`Absențele și loturile nu sunt incluse în această versiune.`,`Fotbalul are variație mare, mai ales pe piețe de goluri.`],
  verdict:`${home} vs ${away} pare un meci care merită analizat atent. MatchMind IQ oferă un scor orientativ, nu o predicție garantată.`}
}
