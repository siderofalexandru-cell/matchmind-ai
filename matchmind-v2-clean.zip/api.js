const API_CONFIG = { BASE_URL: 'https://api.football-data.org/v4', CACHE_DURATION: 10 * 60 * 1000 };
const STORAGE_KEYS = { API_KEY: 'matchmind_api_key' };
class MatchMindAPI{
  constructor(){this.apiKey=localStorage.getItem(STORAGE_KEYS.API_KEY)||'';this.cache=new Map()}
  setApiKey(key){this.apiKey=(key||'').trim();localStorage.setItem(STORAGE_KEYS.API_KEY,this.apiKey)}
  getApiKey(){return this.apiKey||localStorage.getItem(STORAGE_KEYS.API_KEY)||''}
  getFromCache(k){const c=this.cache.get(k);if(!c)return null;if(Date.now()-c.timestamp>API_CONFIG.CACHE_DURATION){this.cache.delete(k);return null}return c.data}
  saveToCache(k,d){this.cache.set(k,{data:d,timestamp:Date.now()})}
  async makeRequest(endpoint){const token=this.getApiKey();if(!token)throw new Error('Tokenul football-data.org nu este configurat.');const cached=this.getFromCache(endpoint);if(cached)return cached;const r=await fetch(API_CONFIG.BASE_URL+endpoint,{headers:{'X-Auth-Token':token}});if(r.status===401||r.status===403)throw new Error('Token invalid sau fără acces.');if(r.status===429)throw new Error('Prea multe cereri. Încearcă mai târziu.');if(!r.ok)throw new Error('Eroare API: '+r.status);const data=await r.json();this.saveToCache(endpoint,data);return data}
  async getTodayFixtures(){const data=await this.makeRequest('/matches');return (data.matches||[]).map(m=>this.normalizeMatch(m))}
  normalizeMatch(m){return{fixture:{id:m.id,date:m.utcDate,time:new Date(m.utcDate).toLocaleTimeString('ro-RO',{hour:'2-digit',minute:'2-digit'}),status:{short:this.mapStatus(m.status)},venue:{name:'Stadion indisponibil'}},teams:{home:{id:m.homeTeam?.id,name:m.homeTeam?.name||'Gazde'},away:{id:m.awayTeam?.id,name:m.awayTeam?.name||'Oaspeți'}},league:{id:m.competition?.id,name:m.competition?.name||'Competiție',round:m.matchday?`Etapa ${m.matchday}`:''},score:{fulltime:{home:m.score?.fullTime?.home,away:m.score?.fullTime?.away}}}}
  mapStatus(s){return{SCHEDULED:'NS',TIMED:'NS',IN_PLAY:'LIVE',PAUSED:'HT',FINISHED:'FT',POSTPONED:'PST',SUSPENDED:'SUSP',CANCELED:'CANC'}[s]||s||'NS'}
  clearCache(){this.cache.clear()}
}
const api=new MatchMindAPI();
