# MatchMind AI
PWA mobilă pentru analiză fotbal. Folosește football-data.org pentru meciurile zilei și analiză orientativă MatchMind IQ.
